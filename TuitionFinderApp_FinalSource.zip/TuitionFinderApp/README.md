
# Tuition Finder App

A Flutter-based mobile app for students to post tuition ads and teachers to view/apply.

## Features
- Post a tuition (subject, location, details)
- View list of available tuitions
- No login/signup required

## How to Build with GitHub Actions (or local)
1. Clone or download this repo.
2. Run:
   ```bash
   flutter pub get
   flutter build apk
   ```
3. Install from `/build/app/outputs/flutter-apk/app-release.apk`
