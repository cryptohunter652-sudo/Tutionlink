
class Tuition {
  final String subject;
  final String location;
  final String details;

  Tuition({required this.subject, required this.location, required this.details});
}
