
import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/tuition.dart';

class PostTuitionScreen extends StatefulWidget {
  @override
  _PostTuitionScreenState createState() => _PostTuitionScreenState();
}

class _PostTuitionScreenState extends State<PostTuitionScreen> {
  final _formKey = GlobalKey<FormState>();
  String subject = '', location = '', details = '';

  void _submit() {
    if (_formKey.currentState!.validate()) {
      sampleTuitions.add(Tuition(subject: subject, location: location, details: details));
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tuition Posted!')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Post a Tuition')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Subject'),
                validator: (val) => val!.isEmpty ? 'Enter subject' : null,
                onChanged: (val) => subject = val,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Location'),
                validator: (val) => val!.isEmpty ? 'Enter location' : null,
                onChanged: (val) => location = val,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Details'),
                onChanged: (val) => details = val,
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _submit, child: Text('Submit')),
            ],
          ),
        ),
      ),
    );
  }
}
