
import 'package:flutter/material.dart';
import 'post_tuition_screen.dart';
import 'view_tuitions_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tuition Finder')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PostTuitionScreen()));
              },
              child: Text('Post Tuition'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ViewTuitionsScreen()));
              },
              child: Text('View Tuitions'),
            ),
          ],
        ),
      ),
    );
  }
}
