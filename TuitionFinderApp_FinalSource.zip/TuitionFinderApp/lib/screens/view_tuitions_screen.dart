
import 'package:flutter/material.dart';
import '../data/sample_data.dart';

class ViewTuitionsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Available Tuitions')),
      body: ListView.builder(
        itemCount: sampleTuitions.length,
        itemBuilder: (context, index) {
          final tuition = sampleTuitions[index];
          return ListTile(
            title: Text(tuition.subject),
            subtitle: Text('${tuition.location}\n${tuition.details}'),
          );
        },
      ),
    );
  }
}
