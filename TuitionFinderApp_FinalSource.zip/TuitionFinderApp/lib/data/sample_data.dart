
import '../models/tuition.dart';

List<Tuition> sampleTuitions = [];
